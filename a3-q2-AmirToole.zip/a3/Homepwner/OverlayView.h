//
//  OverlayView.h
//  A3-AmirToole
//
//  Created by amir on 2013-08-16.
//
//

#import <UIKit/UIKit.h>

@interface OverlayView : UIView

@property (strong, nonatomic) UIColor *crossHairColor;

@end
