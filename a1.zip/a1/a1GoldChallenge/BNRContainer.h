//
//  BNRContainer.h
//  RandomPossessions
//
//  Created by amir on 2013-06-23.
//
//

#import "BNRItem.h"

@interface BNRContainer : BNRItem

- (void) addItem:(id) item;
//- (NSString *)description;

@end
